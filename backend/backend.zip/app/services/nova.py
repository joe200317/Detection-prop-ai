import base64
import io
import json
import re
from typing import Any
from urllib.parse import quote

import httpx

from app.config import settings
from app.services.errors import AIServiceError

IDENTIFY_PROMPT = """
You are a careful visual object identification system for a physical prop inventory.

TASK:
Identify the actual physical object visible in the image. Correct identification is more important than guessing.

IDENTIFICATION RULES:
1. Examine the complete visible object, including its outline, surface, texture, packaging, shape, proportions, and distinctive features.
2. Identify the object by its visible physical evidence, not by what you expect to see in a theme.
3. Distinguish objects that may look similar:
   - Chocolate vs book
   - Toy vs real object
   - Gift box vs book
   - Hat vs helmet
   - Necklace vs garland
   - Cloth vs background decoration
4. A rectangular shape alone does not prove that an object is a book.
   A brown color alone does not prove that an object is chocolate.
5. Look for distinguishing evidence, such as chocolate wrapping, confectionery shape, book pages, a spine, printed covers, seams, straps, or recognizable construction.
6. Do not invent details that are not visible.
7. If the object cannot be identified reliably, use "unknown object" for detectedObject, reduce confidence, and set usable to false.
8. If multiple objects are visible, identify the main object only. Use scene detection for multiple props.
9. Do not infer an object's identity from its color alone.
10. Describe material only when visually supported. Otherwise use "unknown".

OUTPUT:
Return valid JSON only, without markdown or additional text.

Required keys:
{
  "detectedObject": "specific object name",
  "category": "specific object category",
  "role": "prop",
  "color": "observed color",
  "material": "observed or unknown",
  "shape": "observed shape",
  "visualFeatures": ["distinctive visible features"],
  "confidence": 0.0,
  "usable": true
}

Use only these role values:
prop, baby accessory, clothing, furniture, setup, accessory, background item, other.

CONFIDENCE:
0.90-1.00: clear, distinctive visual evidence.
0.70-0.89: likely identity with useful supporting evidence.
0.40-0.69: ambiguous; multiple identities remain possible.
0.00-0.39: object is unclear or unidentifiable.

Set usable to false if the image is blurry, empty, or the object's identity cannot be established reliably.
Never invent an inventory ID.
"""
VERIFY_PROMPT = """
You are a strict physical inventory identity verification system.

TASK:
Compare the detected object from a theme photograph against the supplied inventory candidates.

The detected object name is authoritative for the requested object category. Do not rename it to fit a candidate.

IDENTITY RULES:
1. First determine whether each candidate is the same kind of physical object as the detected object.
2. Compare object type, shape, construction, distinctive features, and visible details.
3. Color similarity alone is never sufficient.
4. Similar size, shape, or material alone is never sufficient.
5. A chocolate is not a book. A gift box is not automatically a book. A toy version is not automatically the same type as a real object.
6. Do not choose an unrelated candidate merely because it is the closest available option.
7. EXACT requires strong visual evidence that the candidate is the same physical inventory item.
8. SIMILAR means the candidate is the same kind of object, but its physical identity is not confirmed.
9. NO_MATCH means no candidate is a defensible match for the detected object.
10. If the supplied images or candidate descriptions are insufficient to establish identity, do not claim EXACT.
11. Inventory status indicates availability only. Never use it as evidence of object identity.
12. Select inventoryId only from the supplied candidates.
13. For NO_MATCH, inventoryId must be null.

OUTPUT:
Return valid JSON only:
{
  "decision": "EXACT",
  "inventoryId": "candidate ID or null",
  "confidence": 0.0,
  "reason": "short explanation based on visual evidence"
}

Allowed decisions: EXACT, SIMILAR, NO_MATCH.
"""

SCENE_PROMPT = """
You are a visual scene inventory detector. Identify physical objects in the entire photograph.

OBJECT COVERAGE:
1. Inspect the entire image from edge to edge.
2. Identify every clearly visible physical prop, including small objects, partially hidden objects, decorations, toys, gifts, books, chocolate, hats, clothing, jewelry, furniture, and background props.
3. Include objects worn or held by a person.
4. Skip only the person's face, plain empty walls, and non-object image regions.
5. Do not omit an object simply because it is small or partly occluded.
6. Each distinct physical item must have exactly one entry.
7. Do not split one physical object into multiple entries.
8. Do not create duplicate entries for the same object.

IDENTITY ACCURACY:
9. Name each object using visible visual evidence.
10. Never identify an object from color or rectangular shape alone.
11. Distinguish chocolate from books, gift boxes from books, toys from real objects, and similar-looking props.
12. Do not guess an object's identity based on the theme or surrounding objects.
13. If an object is visible but cannot be identified reliably, use "unknown object", set usable to false, and assign low confidence.
14. Never fabricate an object that is not visible.
15. A partially visible object can still be included if its identity is sufficiently clear.

COMPLETE BOUNDING BOX:
16. Use normalized integer coordinates from 0 to 1000 across the full image.
17. xmin and ymin represent the object's left and top boundaries.
18. xmax and ymax represent the object's right and bottom boundaries.
19. Include the entire visible object, including protruding parts, handles, ribbons, hat brims, tails, pom-poms, and thin edges.
20. Do not crop the box to only the most recognizable part of an object.
21. Do not extend the box to include neighboring objects.
22. Include a small amount of surrounding background if necessary to avoid cutting off the object.
23. Ensure xmin < xmax and ymin < ymax.

OUTPUT:
Return valid JSON only in this exact structure:
{
  "props": [
    {
      "detectedObject": "specific object name",
      "category": "specific category",
      "role": "prop",
      "color": "observed color",
      "material": "observed or unknown",
      "shape": "observed shape",
      "visualFeatures": ["distinctive visible features"],
      "confidence": 0.0,
      "usable": true,
      "box": {
        "xmin": 0,
        "ymin": 0,
        "xmax": 1000,
        "ymax": 1000
      }
    }
  ]
}

Use only these role values:
prop, baby accessory, clothing, furniture, setup, accessory, background item, other.

Return one entry per physical object. Return an empty props array only if no physical props are visible.
Do not invent inventory IDs.
"""

BOX_PROMPT = """
Locate the complete visible physical object identified as "{name}" in the full photograph.

Return valid JSON only:
{
  "box": {
    "xmin": 0,
    "ymin": 0,
    "xmax": 1000,
    "ymax": 1000
  }
}

RULES:
1. Coordinates are normalized from 0 to 1000 across the full image width and height.
2. Include the complete visible object, not just its center or most recognizable part.
3. Include all visible protrusions, edges, handles, ribbons, tails, brims, and pom-poms.
4. Keep the box tight around the requested object.
5. Do not include neighboring objects as part of the requested object.
6. A little background is preferable to cutting off the object.
7. If multiple instances exist, locate the instance specified by the caller. If no instance can be distinguished, the caller must resolve the ambiguity.
8. Never return invalid or reversed coordinates.
""" 

_IMAGE_FORMATS = {
    "image/jpeg": "jpeg",
    "image/jpg": "jpeg",
    "image/png": "png",
    "image/webp": "webp",
    "image/gif": "gif",
}


def _as_object(parsed: Any) -> dict[str, Any] | None:
    if isinstance(parsed, dict):
        return parsed
    if isinstance(parsed, list):
        return {"props": parsed}
    return None


def _loads(text: str) -> dict[str, Any] | None:
    try:
        return _as_object(json.loads(text))
    except json.JSONDecodeError:
        return None


def _scan_json(chunk: str) -> tuple[list[str], bool, int]:
    stack: list[str] = []
    in_string = False
    escape = False
    last_complete = -1
    for index, char in enumerate(chunk):
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
                last_complete = index
            continue
        if char == '"':
            in_string = True
            continue
        if char == "{":
            stack.append("}")
        elif char == "[":
            stack.append("]")
        elif char in "}]" and stack and stack[-1] == char:
            stack.pop()
            last_complete = index
        elif char == ",":
            last_complete = index
    return stack, in_string, last_complete


def _repair_json(text: str) -> dict[str, Any] | None:
    starts = [index for index in (text.find("{"), text.find("[")) if index >= 0]
    if not starts:
        return None
    chunk = text[min(starts) :]
    stack, in_string, last_complete = _scan_json(chunk)
    if in_string or stack:
        if last_complete < 0:
            return None
        chunk = re.sub(r",\s*$", "", chunk[: last_complete + 1])
        chunk = re.sub(r":\s*$", "", chunk)
        stack, in_string, _last = _scan_json(chunk)
        if in_string:
            return None
        chunk = re.sub(r",\s*$", "", chunk)
        chunk += "".join(reversed(stack))
    chunk = re.sub(r",\s*([}\]])", r"\1", chunk)
    return _loads(chunk)


def parse_model_json(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    parsed = _loads(cleaned)
    if parsed is None:
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start >= 0 and end > start:
            parsed = _loads(cleaned[start : end + 1])
    if parsed is None:
        parsed = _repair_json(cleaned)
    if parsed is None:
        preview = " ".join(cleaned.split())[:180]
        raise AIServiceError(f"Nova returned invalid JSON: {preview}", "invalid_json")
    return parsed


def normalize_detection(payload: dict[str, Any]) -> dict[str, Any]:
    features = payload.get("visualFeatures") or []
    if not isinstance(features, list):
        features = [str(features)]
    try:
        confidence = float(payload.get("confidence") or 0)
    except (TypeError, ValueError):
        confidence = 0
    confidence = min(max(confidence, 0), 1)
    usable = payload.get("usable")
    if usable is None:
        usable = bool(str(payload.get("detectedObject") or "").strip()) and confidence >= 0.45
    return {
        "detectedObject": str(payload.get("detectedObject") or "").strip(),
        "category": str(payload.get("category") or "").strip(),
        "role": str(payload.get("role") or "other").strip() or "other",
        "color": str(payload.get("color") or "").strip(),
        "material": str(payload.get("material") or "").strip(),
        "shape": str(payload.get("shape") or "").strip(),
        "visualFeatures": [str(feature) for feature in features if str(feature).strip()],
        "confidence": confidence,
        "usable": bool(usable),
    }


def normalize_verification(payload: dict[str, Any], allowed_ids: set[str]) -> dict[str, Any]:
    decision = str(payload.get("decision") or "NO_MATCH").strip().upper()
    if decision not in {"EXACT", "SIMILAR", "NO_MATCH"}:
        decision = "NO_MATCH"
    inventory_id = payload.get("inventoryId")
    inventory_id = str(inventory_id).strip() if inventory_id else None
    if inventory_id not in allowed_ids:
        inventory_id = None
        if decision == "EXACT":
            decision = "NO_MATCH"
    try:
        confidence = float(payload.get("confidence") or 0)
    except (TypeError, ValueError):
        confidence = 0
    return {
        "decision": decision,
        "inventoryId": inventory_id,
        "confidence": min(max(confidence, 0), 1),
        "reason": str(payload.get("reason") or "").strip(),
    }


def _as_jpeg(data: bytes) -> tuple[bytes, str]:
    try:
        from PIL import Image
    except ImportError as exc:
        raise AIServiceError("This image format is not supported by Nova", "unsupported") from exc
    image = Image.open(io.BytesIO(data)).convert("RGB")
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=90)
    return buffer.getvalue(), "jpeg"


def _image_bytes(data: bytes, content_type: str) -> tuple[bytes, str]:
    image_format = _IMAGE_FORMATS.get((content_type or "").split(";", 1)[0].strip().lower())
    if image_format:
        return data, image_format
    return _as_jpeg(data)


def _box(value: Any) -> dict[str, float] | None:
    if not isinstance(value, dict):
        return None
    try:
        if any(key in value for key in ("xmin", "xmax", "ymin", "ymax")):
            xmin = float(value.get("xmin") or 0)
            ymin = float(value.get("ymin") or 0)
            xmax = float(value.get("xmax") or 0)
            ymax = float(value.get("ymax") or 0)
            scale = 1000 if max(xmin, ymin, xmax, ymax) > 1.5 else 1
            x = xmin / scale
            y = ymin / scale
            width = (xmax - xmin) / scale
            height = (ymax - ymin) / scale
        else:
            x = float(value.get("x"))
            y = float(value.get("y"))
            width = float(value.get("width") if value.get("width") is not None else value.get("w"))
            height = float(value.get("height") if value.get("height") is not None else value.get("h"))
            if max(x, y, width, height) > 1:
                x, y, width, height = x / 100, y / 100, width / 100, height / 100
    except (TypeError, ValueError):
        return None
    x = min(max(x, 0), 1)
    y = min(max(y, 0), 1)
    width = min(max(width, 0), 1)
    height = min(max(height, 0), 1)
    if width < 0.02 or height < 0.02:
        return None
    if x + width > 1:
        width = 1 - x
    if y + height > 1:
        height = 1 - y
    return {"x": x, "y": y, "width": width, "height": height}


def _prop_name(item: dict[str, Any]) -> str:
    for key in ("detectedObject", "name", "object", "label", "item", "prop"):
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _prop_list(payload: dict[str, Any]) -> list[Any] | None:
    for key in ("props", "objects", "items", "detections"):
        value = payload.get(key)
        if isinstance(value, list):
            return value
    for value in payload.values():
        if isinstance(value, list) and value and all(isinstance(entry, dict) for entry in value):
            return value
    if _prop_name(payload):
        return [payload]
    return None


def normalize_scene(payload: dict[str, Any]) -> list[dict[str, Any]]:
    props = _prop_list(payload)
    if props is None:
        raise AIServiceError("Nova returned invalid JSON", "invalid_json")
    found: list[dict[str, Any]] = []
    for item in props:
        if not isinstance(item, dict):
            continue
        named = dict(item)
        name = _prop_name(named)
        if not name:
            continue
        named["detectedObject"] = name
        detection = normalize_detection(named)
        detection["detectedObject"] = name
        detection["usable"] = True
        box = named.get("box") or named.get("boundingBox") or named.get("bbox")
        detection["box"] = _box(box) if isinstance(box, dict) else None
        found.append(detection)
        if len(found) >= 12:
            break
    return found


def _image_block(data: bytes, content_type: str) -> dict[str, Any]:
    image, image_format = _image_bytes(data, content_type)
    return {
        "image": {
            "format": image_format,
            "source": {"bytes": base64.b64encode(image).decode("ascii")},
        }
    }


class NovaClient:
    def __init__(self) -> None:
        self.vision_model = settings.nova_model_id
        self.embedding_model = f"{settings.nova_embedding_model_id}:{settings.nova_embedding_dimension}"

    def _headers(self) -> dict[str, str]:
        token = settings.aws_bearer_token_bedrock.strip()
        if not token:
            raise AIServiceError("Bedrock API key is not configured", "config")
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _url(self, model_id: str, action: str) -> str:
        region = settings.aws_region.strip() or "us-east-1"
        return f"https://bedrock-runtime.{region}.amazonaws.com/model/{quote(model_id, safe='')}/{action}"

    async def _post(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=settings.nova_timeout_seconds) as client:
                response = await client.post(url, json=payload, headers=self._headers())
        except httpx.TimeoutException as exc:
            raise AIServiceError("Nova request timed out", "timeout") from exc
        except httpx.HTTPError as exc:
            raise AIServiceError("Nova request failed", "nova") from exc
        if response.status_code == 429:
            raise AIServiceError("Nova rate limit reached", "rate_limit")
        if response.status_code >= 400:
            detail = _error_detail(response)
            raise AIServiceError(detail or "Nova request failed", "nova")
        try:
            return response.json()
        except json.JSONDecodeError as exc:
            raise AIServiceError("Nova returned invalid JSON", "invalid_json") from exc

    def _response_text(self, body: dict[str, Any]) -> str:
        try:
            parts = body["output"]["message"]["content"]
        except (KeyError, TypeError) as exc:
            raise AIServiceError("Nova returned invalid JSON", "invalid_json") from exc
        text = "".join(part.get("text", "") for part in parts if isinstance(part, dict))
        if not text.strip():
            raise AIServiceError("Nova returned invalid JSON", "invalid_json")
        return text

    async def _converse(self, content: list[dict[str, Any]], *, max_tokens: int = 1024) -> tuple[str, dict[str, Any]]:
        body = await self._post(
            self._url(self.vision_model, "converse"),
            {
                "messages": [{"role": "user", "content": content}],
                "inferenceConfig": {"maxTokens": max_tokens, "temperature": 0},
            },
        )
        return self._response_text(body), body.get("usage") or {}

    async def discover(self, image: bytes, content_type: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        text, usage = await self._converse(
            [_image_block(image, content_type), {"text": SCENE_PROMPT}],
            max_tokens=4096,
        )
        found = normalize_scene(parse_model_json(text))
        if found:
            return found, usage
        text, usage = await self._converse(
            [
                _image_block(image, content_type),
                {
                    "text": (
                        "Name every object you can see, including a hat or clothes worn by a person. "
                        'Return only JSON {"props":[{"detectedObject":"","usable":true,'
                        '"box":{"xmin":0,"ymin":0,"xmax":1000,"ymax":1000}}]}. '
                        "Do not return an empty list."
                    )
                },
            ],
            max_tokens=2048,
        )
        return normalize_scene(parse_model_json(text)), usage

    async def refine_box(self, image: bytes, content_type: str, name: str) -> dict[str, float] | None:
        text, _usage = await self._converse(
            [_image_block(image, content_type), {"text": BOX_PROMPT.format(name=name)}],
            max_tokens=300,
        )
        payload = parse_model_json(text)
        return _box(payload.get("box") if isinstance(payload.get("box"), dict) else payload)

    async def identify(
        self,
        image: bytes,
        content_type: str,
        *,
        theme_name: str = "",
        theme_image: bytes | None = None,
        theme_type: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        content: list[dict[str, Any]] = [
            _image_block(image, content_type),
            {"text": IDENTIFY_PROMPT},
        ]
        if theme_name:
            content.append({"text": f"Theme context: {theme_name}."})
        if theme_image and theme_type:
            content.append({"text": "Main theme image for context only."})
            content.append(_image_block(theme_image, theme_type))
        text, usage = await self._converse(content)
        return normalize_detection(parse_model_json(text)), usage

    async def verify(
        self,
        image: bytes,
        content_type: str,
        detection: dict[str, Any],
        candidates: list[dict[str, Any]],
        candidate_images: list[tuple[str, bytes, str]],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        lines = [
            f"Detected: {detection.get('detectedObject')} ({detection.get('category')}), "
            f"material {detection.get('material')}, color {detection.get('color')}, shape {detection.get('shape')}."
        ]
        for candidate in candidates:
            lines.append(
                f"{candidate['inventoryId']} name={candidate.get('name')} "
                f"category={candidate.get('category')} status={candidate.get('status')} "
                f"similarity={candidate.get('bestSimilarity')}"
            )
        content: list[dict[str, Any]] = [
            {"text": "Source prop image."},
            _image_block(image, content_type),
            {"text": VERIFY_PROMPT + "\n" + "\n".join(lines)},
        ]
        for inventory_id, data, media_type in candidate_images:
            content.append({"text": f"Candidate {inventory_id}."})
            content.append(_image_block(data, media_type))
        text, usage = await self._converse(content)
        allowed = {candidate["inventoryId"] for candidate in candidates}
        return normalize_verification(parse_model_json(text), allowed), usage

    async def embed(
        self,
        image: bytes,
        content_type: str,
        *,
        purpose: str = "GENERIC_INDEX",
    ) -> tuple[list[float], dict[str, Any]]:
        image, image_format = _image_bytes(image, content_type)
        body = await self._post(
            self._url(settings.nova_embedding_model_id, "invoke"),
            {
                "schemaVersion": "nova-multimodal-embed-v1",
                "taskType": "SINGLE_EMBEDDING",
                "singleEmbeddingParams": {
                    "embeddingPurpose": purpose,
                    "embeddingDimension": settings.nova_embedding_dimension,
                    "image": {
                        "format": image_format,
                        "detailLevel": "STANDARD_IMAGE",
                        "source": {"bytes": base64.b64encode(image).decode("ascii")},
                    },
                },
            },
        )
        embeddings = body.get("embeddings") or []
        vector = embeddings[0].get("embedding") if embeddings and isinstance(embeddings[0], dict) else None
        if not isinstance(vector, list) or not vector:
            raise AIServiceError("Embedding generation failed", "embedding")
        return [float(value) for value in vector], {}


def _error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except json.JSONDecodeError:
        payload = None
    message = ""
    if isinstance(payload, dict):
        message = str(payload.get("message") or payload.get("Message") or "").strip()
    if not message:
        message = response.text.strip()
    message = " ".join(message.split())
    if len(message) > 240:
        message = message[:240].rstrip()
    return message


_override: NovaClient | None = None


def set_nova_client(client: NovaClient | None) -> None:
    global _override
    _override = client


def get_nova_client() -> NovaClient:
    return _override or NovaClient()
